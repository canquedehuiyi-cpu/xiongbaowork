# 统一展开源码基线：开工前必读

状态：PREPARED，等待 Root 核验及模型 ACK；没有启动 Qoder 或 ww。
这只是恢复工作基线，不是完整 C88，也不代表构建或产品验收通过。

输入：已校验旧 ZIP（9435160B，cfed20861da92d062c1d5d4a0c768ac6c2e95f014904323533517fac2a550adc），只叠加 Gitee3383163 的三个桌面工具链原文件。ZIP中三路径原先均不存在，零覆盖碰撞。候选703c874另两项插件修改未携入；两个插件文件都保持 ZIP 字节。

源码目录：/workspace/scratch/3d93691fe5e9/source-reconstruction-20261018/cloud-dev-baseline-20261018/source
源码文件数：1875；原始字节：34529259。
全树摘要：a81cd0487fd515911e1506d0a83ba532568f52bad90f0a8f8367da675392f785。算法在 source-manifest.json 中；每个相对路径、字节数、SHA256、mode均记录。
确定性源码包 SHA256：75b2aa411dc58e7bfc84afaac78853e38eac481b04d208f95c8bfe32bb68ab4f。
tar仅有源码文件，排除.git、node_modules、真实.env/凭据/数据库/运行态数据；原 ZIP 无这些排除项，保留.env.example等样例。不包含候选恢复报告、依赖缓存或模型配置。

## 两条云端工作区

Qoder / Qwen3.8-flash（A1）：/workspace/scratch/3d93691fe5e9/source-reconstruction-20261018/cloud-dev-baseline-20261018/workspaces/qoder-A1
分支：codex/qoder-task-workbench-20261018
ww / WorkBuddy / GLM5.3-flash（B1）：/workspace/scratch/3d93691fe5e9/source-reconstruction-20261018/cloud-dev-baseline-20261018/workspaces/ww-B1
分支：codex/workbuddy-cloud-validation-20261018
远程执行器：Linux / b2f0631c65fa（同一云端主机，不是两台远程主机）。工作目录是独立实文件拷贝，不共享inode、node_modules、端口或数据库。服务均未启动。
两者干净初始合成提交：9ba4ea9fae4b994425a49c3e6eec9ddc0d156e05；Git tree：0064aba2afa7a6c1a90ee43b32fc26847f9192ef。此提交只存在云端新工作区，不能冒称 Gitee 对象。
两者全树摘要相同；没有配置Git远端，也没有证明指定客户端已接入。模型必须在各自真实远程执行器中ACK hostname、cwd、tree摘要、Git身份和模型标签；如无法访问这些目录，应回BLOCKED，不落本机、不自行重选历史版本。

## 任务与边界

A任务书：https://chatgpt.com/space/page_3370e90507088191a948beae38e95ffb。A1只处理冻结范围中的任务查询条件与URL状态。真实任务路由：openbot/app/src/routes/_authed/_app/tasks.tsx（32954B，0e74e3977cf6a35f16675a2a983d84d6bbe34839eeaa7d54647e89880757d339）。四个原tasks测试和app bunfig/preload均存在。boardSearch当前不存在，由指定owner按任务书新增；不要恢复历史整页或改review/archive授权动作。
B任务书：https://chatgpt.com/space/page_ecf07f6e5a38819189b17b5a7e57dfef。B1独占openbot/scripts/cloud-dev/**及openbot/docs/cloud-dev/**；当前这些实现尚未创建。只做标准库doctor，后续verify遵守固定argv白名单。仓库根没有package.json，workspace根是openbot/。
每包最多8个源/测试文件。两线不自行提交/推送，由Codex审查差异后安排集成。不开工评论，本次不代跑指定模型。

## 依赖与验证事实

openbot/bun.lock：453991B，c5b3f3c17b2159e033c7cf8911780b98d0ebeba93756e175e32064b15849e670；声明Bun1.3.14，锁定TypeScript5.9.3。新工作区无node_modules，产品测试/构建目前BLOCKED：缺各自隔离安装的锁定依赖。本次不安装、不复跑已通过测试。
原7条服务端TS诊断仍为已知失败参考，不代表新工作区已实跑：
- openbot/server/src/agents/plan-model.ts(93,39): TS7006: Parameter 'part' implicitly has an 'any' type.
- openbot/server/src/agents/plan-model.ts(108,50): TS7006: Parameter 'part' implicitly has an 'any' type.
- openbot/server/src/agents/plan-model.ts(126,21): TS7006: Parameter 'part' implicitly has an 'any' type.
- openbot/server/src/agents/plan-model.ts(281,46): TS7006: Parameter 'tool' implicitly has an 'any' type.
- openbot/server/src/agents/plan-model.ts(292,38): TS7006: Parameter 'tool' implicitly has an 'any' type.
- openbot/server/src/telemetry/otel.ts(165,48): TS2739: Type 'OTLPLogExporter' is missing the following properties from type 'LogRecordExporter': export, shutdown, forceFlush
- openbot/server/src/voice/summary.ts(60,23): TS7006: Parameter 'part' implicitly has an 'any' type.

既有 server build/typecheck = tsc --noEmit；当前server/tsconfig不包含tests。root build/test可能触发generate-app-config读取.env，未经非秘密配置审阅不可执行；保留原bun预加载及MINIMUM_TESTS=400。此前完整依赖安装180秒超时，不得写全绿。Windows/DB/RLS/live SDK/provider/产品验收未运行。禁止部署、收费provider、生产数据和本地工程落盘。
