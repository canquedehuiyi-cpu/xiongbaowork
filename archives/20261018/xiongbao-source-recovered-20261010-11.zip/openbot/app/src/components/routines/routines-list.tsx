import { IconHistory, IconPlayerPlay, IconTrash } from "@tabler/icons-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { PageSection } from "@/components/layout/page-shell";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyTitle,
} from "@/components/ui/empty";
import {
  Item,
  ItemActions,
  ItemContent,
  ItemDescription,
  ItemFooter,
  ItemTitle,
} from "@/components/ui/item";
import { Switch } from "@/components/ui/switch";
import { relativeTime } from "@/lib/relative-time";
import {
  deleteRoutineMutationOptions,
  runRoutineNowMutationOptions,
  setRoutineEnabledMutationOptions,
} from "@/lib/routines/mutations";
import {
  nothingIsFiring,
  type RoutineRecord,
  type RoutineRunRecord,
  routineRunsQueryOptions,
  routinesQueryOptions,
} from "@/lib/routines/queries";
import { cn } from "@/lib/utils";
import { queryClient } from "@/query-client";

/**
 * What the last-run cell says, and in what tone.
 *
 * `lastRun === null` and `lastRun.status === null` are different facts, and saying the wrong one
 * invents news: the first is "this routine has never finished a run," the second is "one is open
 * right now" — which is also what a run stuck open after repeated dispatch failures looks like from
 * here. Neither is a failure, so neither gets the destructive tone; only `status: "failed"` does.
 */
function lastRunLabel(lastRun: RoutineRecord["lastRun"]): {
  text: string;
  className: string;
  /** The chip's dot, which carries the tone so the text can stay readable. */
  dot: string;
} {
  if (lastRun === null) {
    return {
      text: "还没运行过",
      className: "text-muted-foreground",
      dot: "bg-muted-foreground/40",
    };
  }
  if (lastRun.status === null) {
    return {
      text: "正在运行…",
      className: "text-muted-foreground",
      dot: "animate-pulse bg-muted-foreground",
    };
  }
  const when = lastRun.at ? relativeTime(lastRun.at) : "最近";
  if (lastRun.status === "failed") {
    return {
      text: `${when}失败`,
      className: "text-destructive",
      dot: "bg-destructive",
    };
  }
  if (lastRun.status === "skipped") {
    return {
      text: `${when}跳过`,
      className: "text-amber-600 dark:text-amber-500",
      dot: "bg-amber-500",
    };
  }
  if (lastRun.status === "succeeded") {
    return {
      text: `${when}运行过`,
      className: "text-muted-foreground",
      dot: "bg-emerald-500",
    };
  }
  // An outcome this DTO doesn't recognise degrades to a neutral label rather than an invented
  // success — the contract typing (`RoutineRunOutcome | null`) makes a fourth outcome a build-time
  // error, but this is the runtime fallback if that ever slips through.
  return {
    text: `${when}结束`,
    className: "text-muted-foreground",
    dot: "bg-muted-foreground/40",
  };
}

/**
 * One fact about a routine, worn as a small pill so the footer reads as a row of states rather
 * than a sentence. On the muted item the pill's own background is what keeps it legible.
 */
function Chip({
  className,
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-border bg-background/60 px-2 py-0.5 text-xs",
        className,
      )}
    >
      {children}
    </span>
  );
}

const RUN_STATUS: Record<
  RoutineRunRecord["status"],
  { text: string; dot: string; className: string }
> = {
  running: {
    text: "运行中",
    dot: "animate-pulse bg-muted-foreground",
    className: "",
  },
  succeeded: { text: "成功", dot: "bg-emerald-500", className: "" },
  failed: {
    text: "失败",
    dot: "bg-destructive",
    className: "text-destructive",
  },
  skipped: {
    text: "跳过",
    dot: "bg-amber-500",
    className: "text-amber-600 dark:text-amber-500",
  },
  waiting: { text: "等你处理", dot: "bg-sky-500", className: "" },
};

/** Every firing of one routine, newest first, each linking to the thread it ran in. */
function RoutineRuns({ routine }: { routine: RoutineRecord }) {
  const runs = useQuery(routineRunsQueryOptions(routine.id));
  if (runs.isPending)
    return <p className="text-muted-foreground text-xs">正在读取运行记录…</p>;
  if (runs.error)
    return (
      <p className="text-destructive text-xs" role="alert">
        {runs.error.message}
      </p>
    );
  if (!runs.data?.length)
    return <p className="text-muted-foreground text-xs">还没有运行记录。</p>;
  return (
    <ul className="flex w-full flex-col gap-1.5">
      {runs.data.map((run) => {
        const status = RUN_STATUS[run.status] ?? RUN_STATUS.skipped;
        return (
          <li
            className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs"
            key={run.id}
          >
            <span
              className={cn(
                "inline-flex items-center gap-1.5",
                status.className,
              )}
            >
              <span className={cn("size-1.5 rounded-full", status.dot)} />
              {status.text}
            </span>
            <span className="text-muted-foreground">
              {run.source === "run_now"
                ? "手动运行"
                : run.source === "trigger"
                  ? "事件触发"
                  : "按计划"}{" "}
              · {relativeTime(run.startedAt)}
            </span>
            {routine.channel.gone ? null : (
              <Link
                className="text-muted-foreground underline underline-offset-2 hover:text-foreground"
                params={{ channelId: routine.channel.id }}
                to="/channel/$channelId"
              >
                打开对话
              </Link>
            )}
            {run.error ? (
              <span className="basis-full text-muted-foreground">
                {run.error}
              </span>
            ) : null}
          </li>
        );
      })}
    </ul>
  );
}

/**
 * The signed-in person's standing instructions: a switch to stop one taking effect, and a delete
 * that ends it for good.
 *
 * Scoped by `agentId` on a Bot's own dialog, unscoped on the Routines page. One query either way —
 * the list is owner-scoped and small, so the scope is a filter here rather than a second endpoint.
 */
export function RoutinesList({
  agentId,
  embedded = false,
}: {
  /** Show only the routines this Bot carries out. Absent shows all of the person's. */
  agentId?: string;
  /** Inside a dialog, where the page section's own top margin is somebody else's spacing. */
  embedded?: boolean;
} = {}) {
  const routines = useQuery(routinesQueryOptions());
  const setEnabled = useMutation(setRoutineEnabledMutationOptions(queryClient));
  const deleteRoutine = useMutation(deleteRoutineMutationOptions(queryClient));
  const runNow = useMutation(runRoutineNowMutationOptions(queryClient));
  /** Which routine's run history is open. One at a time keeps the list scannable. */
  const [historyId, setHistoryId] = useState<string | null>(null);
  /** The routine a delete is being confirmed for, or null. Its own dialog rather than one per row. */
  const [confirmingId, setConfirmingId] = useState<string | null>(null);
  const rows = (routines.data?.routines ?? []).filter(
    (row) => agentId === undefined || row.agentId === agentId,
  );
  const sweep = routines.data?.sweep;
  const noWorker = nothingIsFiring(sweep, rows.length);
  const confirming = rows.find((row) => row.id === confirmingId) ?? null;

  return (
    <PageSection className={embedded ? "mt-0" : undefined}>
      {setEnabled.error || runNow.error ? (
        <p className="text-destructive text-sm" role="alert">
          {setEnabled.error?.message ?? runNow.error?.message}
        </p>
      ) : null}

      {noWorker ? (
        <Item
          variant="muted"
          className="mb-2 border-amber-500/40 bg-amber-500/5"
          role="alert"
        >
          <ItemContent>
            <ItemTitle className="text-amber-600 dark:text-amber-500">
              没有在执行这些定时任务
            </ItemTitle>
            <ItemDescription>
              {sweep?.lastSweptAt
                ? `定时任务的执行程序上一次检查是在${relativeTime(sweep.lastSweptAt)}。它重新运行之前，这些都不会触发。`
                : "还没有任何定时任务执行程序报到过，所以这些都不会触发。部署里需要有一个在运行才能执行它们。"}
            </ItemDescription>
          </ItemContent>
        </Item>
      ) : null}

      {/* Pending renders nothing: the empty-state sentence would otherwise flash for the fetch. */}
      {routines.isPending ? null : routines.error ? (
        <p className="mt-4 text-destructive text-sm" role="alert">
          读不到你的定时任务。
        </p>
      ) : rows.length === 0 ? (
        <Empty className="h-[180px] border border-dashed">
          <EmptyHeader>
            <EmptyTitle className="text-muted-foreground">
              {agentId ? "这位员工还没有定时任务" : "还没有定时任务"}
            </EmptyTitle>
            <EmptyDescription>
              {agentId
                ? "在频道里跟它说一句——比如“每个工作日早上 9 点，……”——就会出现在这里；也可以在「自主工作」页直接新建。"
                : "在频道里跟员工说一句——比如“每个工作日早上 9 点，……”——就会出现在这里；也可以在「自主工作」页直接新建。"}
            </EmptyDescription>
          </EmptyHeader>
        </Empty>
      ) : (
        <div className="flex flex-col gap-2">
          {rows.map((routine) => {
            const lastRun = lastRunLabel(routine.lastRun);
            return (
              <Item key={routine.id} variant="muted">
                {/* Paused reads at a glance: the content dims, and a chip below says the word. */}
                <ItemContent className={routine.enabled ? "" : "opacity-60"}>
                  <ItemTitle>
                    {routine.schedule}
                    <span className="font-normal text-muted-foreground text-xs">
                      {routine.timezone}
                    </span>
                  </ItemTitle>
                  <ItemDescription className="line-clamp-2">
                    {routine.instruction}
                  </ItemDescription>
                  {/* A set, so it wraps onto its own line rather than crowding the title. */}
                  <ItemFooter>
                    <div className="flex flex-wrap items-center gap-1.5">
                      {routine.channel.gone ? (
                        <Chip className="border-destructive/40 text-destructive">
                          这个频道已不在
                        </Chip>
                      ) : (
                        // Where it posts is a place, so the chip goes there.
                        <Link
                          params={{ channelId: routine.channel.id }}
                          to="/channel/$channelId"
                        >
                          <Chip className="text-muted-foreground transition-colors hover:text-foreground">
                            {routine.channel.name ?? "未命名频道"}
                          </Chip>
                        </Link>
                      )}
                      <Chip className={lastRun.className}>
                        <span
                          className={cn("size-1.5 rounded-full", lastRun.dot)}
                        />
                        {lastRun.text}
                      </Chip>
                      {/*
                       * Enabled only: the store recomputes nextRunAt on cron/timezone change or
                       * re-enable, so a disabled routine's stamp is frozen in the past — rendering
                       * it unguarded would announce a stale "3 days ago" as the next run. Paused
                       * takes its place, so the switch's state has a word as well as a position.
                       */}
                      {!routine.enabled ? (
                        <Chip className="text-muted-foreground">已暂停</Chip>
                      ) : new Date(routine.nextRunAt).getTime() <=
                        Date.now() ? (
                        /*
                         * A stamp in the past is a firing the sweep has not picked up, and "Next 5
                         * hours ago" is nonsense. Said as what it is: due, and visibly waiting.
                         */
                        <Chip className="text-amber-600 dark:text-amber-500">
                          <span className="size-1.5 animate-pulse rounded-full bg-amber-500" />
                          到点待执行
                        </Chip>
                      ) : (
                        <Chip className="text-muted-foreground">
                          下次 {relativeTime(routine.nextRunAt)}
                        </Chip>
                      )}
                    </div>
                  </ItemFooter>
                  {historyId === routine.id ? (
                    <div className="mt-2 border-border border-t pt-2">
                      <RoutineRuns routine={routine} />
                    </div>
                  ) : null}
                </ItemContent>
                <ItemActions>
                  {/*
                   * Run now is the Test button, and it does real work: the Bot carries out the
                   * instruction in the channel right away. Offered only while the routine is on,
                   * because a paused routine never runs.
                   */}
                  <Button
                    aria-label={`立即运行定时任务「${routine.schedule}」`}
                    disabled={
                      !routine.enabled ||
                      (runNow.isPending && runNow.variables === routine.id)
                    }
                    onClick={() =>
                      runNow.mutate(routine.id, {
                        onSuccess: () => setHistoryId(routine.id),
                      })
                    }
                    size="sm"
                    title={
                      routine.enabled
                        ? "现在就真的运行一次：员工会去做这件事，并在频道里回报。"
                        : "已暂停的定时任务不会运行，先把它打开。"
                    }
                    type="button"
                    variant="outline"
                  >
                    <IconPlayerPlay />
                    立即运行
                  </Button>
                  <Button
                    aria-expanded={historyId === routine.id}
                    aria-label={`定时任务「${routine.schedule}」的运行记录`}
                    onClick={() =>
                      setHistoryId(historyId === routine.id ? null : routine.id)
                    }
                    size="icon-sm"
                    type="button"
                    variant="ghost"
                  >
                    <IconHistory />
                  </Button>
                  {/*
                   * Binary and immediate: it takes effect when switched, there is no save.
                   * Disabled only while its own write is in flight, so switching one routine
                   * does not freeze the rest of the list — the same idiom the per-tool plugins
                   * page uses for its per-Bot grant switches.
                   */}
                  <Switch
                    aria-label={`启用定时任务「${routine.schedule}」`}
                    checked={routine.enabled}
                    disabled={
                      setEnabled.isPending &&
                      setEnabled.variables?.id === routine.id
                    }
                    onCheckedChange={(next) =>
                      setEnabled.mutate({ id: routine.id, enabled: next })
                    }
                  />
                  <Button
                    aria-label={`删除定时任务「${routine.schedule}」`}
                    onClick={() => {
                      deleteRoutine.reset();
                      setConfirmingId(routine.id);
                    }}
                    size="icon-sm"
                    type="button"
                    variant="ghost"
                  >
                    <IconTrash />
                  </Button>
                </ItemActions>
              </Item>
            );
          })}
        </div>
      )}

      {/*
       * One dialog for the whole list rather than one per row, keyed by which routine is being
       * confirmed. It names the schedule, not the id or the instruction, because the schedule is
       * the word a person reads first on the row and the one most likely to tell two routines apart
       * at a glance.
       */}
      <Dialog
        onOpenChange={(open) => {
          if (!open) setConfirmingId(null);
        }}
        open={confirming !== null}
      >
        {/* The heavier backdrop, forced: opened from a Bot's dialog this stacks over it, and Base
            UI would otherwise render a nested dialog with no backdrop at all. */}
        <DialogContent overlayClassName="bg-black/20 supports-backdrop-filter:backdrop-blur-sm">
          <DialogHeader>
            <DialogTitle>删除「{confirming?.schedule}」？</DialogTitle>
            <DialogDescription>
              这条常设指令会永久停止，此后不会再按这个计划运行，无法撤销。
            </DialogDescription>
          </DialogHeader>
          {deleteRoutine.error ? (
            <p className="text-destructive text-sm" role="alert">
              {deleteRoutine.error.message}
            </p>
          ) : null}
          <DialogFooter>
            <Button
              onClick={() => setConfirmingId(null)}
              size="sm"
              variant="ghost"
            >
              取消
            </Button>
            <Button
              disabled={deleteRoutine.isPending}
              onClick={() => {
                if (!confirmingId) return;
                deleteRoutine.mutate(confirmingId, {
                  onSuccess: () => setConfirmingId(null),
                });
              }}
              size="sm"
              variant="destructive"
            >
              {deleteRoutine.isPending ? "正在删除…" : "删除"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageSection>
  );
}
