import { queryOptions } from "@tanstack/react-query";
import { client } from "@/lib/client";

/**
 * One standing instruction, as the Routines page sees it.
 *
 * `schedule` IS OPAQUE DISPLAY TEXT, NEVER A VALUE TO PARSE. The server computes it once, from the
 * same library that decides when the routine actually fires — prose for a shape it recognizes, the
 * raw five-field cron expression for anything stranger than that. Rendering it verbatim is the only
 * correct thing to do with it; a second cron-to-English implementation in the browser would drift
 * out of step with the server's the first time either one changes.
 */
export type RoutineRecord = {
  id: string;
  /** Which Bot carries it out, so a Bot's own dialog can show only its routines. */
  agentId: string;
  schedule: string;
  timezone: string;
  instruction: string;
  channel: { id: string; name: string | null; gone: boolean };
  enabled: boolean;
  nextRunAt: string;
  /**
   * Null means no run has ever finished. An object with `status: null` means a run is open —
   * started but not yet finished, whether genuinely in flight or stuck there after repeated
   * dispatch failures. Neither is a failure; only `status: "failed"` is.
   */
  lastRun: {
    status: "succeeded" | "failed" | "skipped" | null;
    at: string | null;
  } | null;
};

export type SweepRecord = {
  lastSweptAt: string | null;
  working: boolean;
};

export type RoutinesPage = {
  routines: RoutineRecord[];
  sweep: SweepRecord;
};

export function nothingIsFiring(
  sweep: SweepRecord | undefined,
  routineCount: number,
): boolean {
  return sweep !== undefined && !sweep.working && routineCount > 0;
}

export const routineKeys = {
  all: ["routines"] as const,
  list: () => ["routines", "list"] as const,
  runs: (id: string) => ["routines", id, "runs"] as const,
};

/** One firing of a routine, scheduled or Run now. */
export type RoutineRunRecord = {
  id: string;
  status: "running" | "succeeded" | "failed" | "skipped" | "waiting";
  startedAt: string;
  finishedAt: string | null;
  error: string | null;
  /** What started it: the schedule, a person's Run now, or an event trigger. */
  source: "schedule" | "run_now" | "trigger";
};

export function routineRunsQueryOptions(id: string) {
  return queryOptions({
    queryKey: routineKeys.runs(id),
    queryFn: (): Promise<RoutineRunRecord[]> =>
      client(`/api/routines/${encodeURIComponent(id)}/runs`, "runs", {
        fallback: "This routine's runs could not be loaded.",
      }),
    // A run in flight settles within minutes; poll so Running turns into its outcome.
    refetchInterval: 5_000,
  });
}

/**
 * The signed-in person's own routines.
 *
 * Owner-scoped by the server on every read; there is no version of this that takes an owner id,
 * the same way `connectionsQueryOptions` answers only for whoever is asking.
 */
export function routinesQueryOptions() {
  return queryOptions({
    queryKey: routineKeys.list(),
    queryFn: async (): Promise<RoutinesPage> => {
      const response = await client("/api/routines", {
        fallback: "Your routines could not be loaded.",
      });
      const body = (await response.json()) as Partial<RoutinesPage>;
      return {
        routines: body.routines ?? [],
        sweep: body.sweep ?? { lastSweptAt: null, working: false },
      };
    },
  });
}
